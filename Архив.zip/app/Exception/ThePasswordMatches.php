<?php
   namespace App\Exception;



   class ThePasswordMatchesException extends \Exception {
      
   }